"""chuk-mcp-training — MCP tool surface (M0).

Thin client over the control plane's REST API, so the MCP server can run anywhere
(the Mac, typically) while the control plane lives on Fly.

    CHUK_TRAIN_URL=https://train.example.com \
    CHUK_TRAIN_API_TOKEN=... \
    python mcp_server.py            # stdio for mcp-cli / Claude Desktop
"""
from __future__ import annotations

import os
from typing import Any

import httpx
from chuk_mcp_server import ChukMCPServer

BASE = os.environ.get("CHUK_TRAIN_URL", "http://127.0.0.1:8700").rstrip("/")
TOKEN = os.environ.get("CHUK_TRAIN_API_TOKEN", "")

mcp = ChukMCPServer(
    name="chuk-mcp-training",
    version="0.1.0",
    description="MCP-controlled remote training harness (M0: fleet, shell runs, logs)",
)


def _call(method: str, path: str, **kw: Any) -> dict:
    """Error-envelope pattern: tools never raise."""
    try:
        r = httpx.request(method, f"{BASE}{path}",
                          headers={"Authorization": f"Bearer {TOKEN}"}, timeout=30, **kw)
        if r.status_code >= 400:
            return {"ok": False, "error": f"http_{r.status_code}", "detail": r.text[:500]}
        return {"ok": True, "data": r.json()}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "request_failed", "detail": repr(e)}


@mcp.tool
def fleet() -> dict:
    """List all workers: id, GPU/hardware, connection state, heartbeat age, current run."""
    return _call("GET", "/api/fleet")


@mcp.tool
def submit_shell(name: str, command: str, timeout_s: int = 600) -> dict:
    """Submit a shell run to the queue (M0 job kind). Returns the run_id.

    Assigned to the first idle worker; use run_status/tail_logs to follow it.
    """
    return _call("POST", "/api/runs/shell",
                 json={"name": name, "command": command, "timeout_s": timeout_s})


@mcp.tool
def list_runs(limit: int = 20) -> dict:
    """Recent runs with state, worker, and exit code."""
    return _call("GET", f"/api/runs?limit={limit}")


@mcp.tool
def run_status(run_id: str) -> dict:
    """Full record for one run: state, spec, worker, exit code, timestamps."""
    return _call("GET", f"/api/runs/{run_id}")


@mcp.tool
def tail_logs(run_id: str, lines: int = 100) -> dict:
    """Last N log lines for a run (live-streamed from the worker)."""
    return _call("GET", f"/api/runs/{run_id}/logs?lines={lines}")


@mcp.tool
def run_events(run_id: str) -> dict:
    """The run's append-only lifecycle event log (provenance record)."""
    return _call("GET", f"/api/runs/{run_id}/events")


if __name__ == "__main__":
    mcp.run(stdio=True)
