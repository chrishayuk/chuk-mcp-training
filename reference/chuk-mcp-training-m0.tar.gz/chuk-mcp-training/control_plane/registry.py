"""SQLite registry: workers, runs, logs, events. M0 scope."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid

_SCHEMA = """
CREATE TABLE IF NOT EXISTS workers (
  id TEXT PRIMARY KEY,
  labels TEXT NOT NULL DEFAULT '[]',
  hardware TEXT NOT NULL DEFAULT '{}',
  state TEXT NOT NULL DEFAULT 'connected',   -- connected|disconnected
  current_run TEXT,
  joined_at REAL NOT NULL,
  last_heartbeat REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,                        -- shell (M0)
  spec TEXT NOT NULL,                        -- json
  state TEXT NOT NULL DEFAULT 'queued',      -- queued|assigned|running|completed|failed|cancelled
  worker_id TEXT,
  exit_code INTEGER,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS logs (
  run_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  ts REAL NOT NULL,
  line TEXT NOT NULL,
  PRIMARY KEY (run_id, seq)
);
CREATE TABLE IF NOT EXISTS events (
  run_id TEXT NOT NULL,
  ts REAL NOT NULL,
  event TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '{}'
);
"""


class Registry:
    def __init__(self, path: str = "chuk_train.db") -> None:
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._db.executescript(_SCHEMA)
            self._db.commit()

    # -- helpers ------------------------------------------------------------
    def _exec(self, sql: str, params: tuple = ()) -> None:
        with self._lock:
            self._db.execute(sql, params)
            self._db.commit()

    def _rows(self, sql: str, params: tuple = ()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._db.execute(sql, params).fetchall()]

    # -- workers ------------------------------------------------------------
    def upsert_worker(self, worker_id: str, labels: list[str], hardware: dict) -> None:
        now = time.time()
        self._exec(
            """INSERT INTO workers (id, labels, hardware, state, joined_at, last_heartbeat)
               VALUES (?, ?, ?, 'connected', ?, ?)
               ON CONFLICT(id) DO UPDATE SET labels=excluded.labels,
                 hardware=excluded.hardware, state='connected', last_heartbeat=excluded.last_heartbeat""",
            (worker_id, json.dumps(labels), json.dumps(hardware), now, now),
        )

    def heartbeat(self, worker_id: str) -> None:
        self._exec("UPDATE workers SET last_heartbeat=? WHERE id=?", (time.time(), worker_id))

    def worker_disconnected(self, worker_id: str) -> None:
        self._exec("UPDATE workers SET state='disconnected' WHERE id=?", (worker_id,))

    def set_worker_run(self, worker_id: str, run_id: str | None) -> None:
        self._exec("UPDATE workers SET current_run=? WHERE id=?", (run_id, worker_id))

    def fleet(self) -> list[dict]:
        rows = self._rows("SELECT * FROM workers ORDER BY joined_at")
        for r in rows:
            r["labels"] = json.loads(r["labels"])
            r["hardware"] = json.loads(r["hardware"])
            r["heartbeat_age_s"] = round(time.time() - r["last_heartbeat"], 1)
        return rows

    # -- runs ---------------------------------------------------------------
    def create_run(self, name: str, kind: str, spec: dict) -> str:
        run_id = uuid.uuid4().hex[:12]
        now = time.time()
        self._exec(
            "INSERT INTO runs (id, name, kind, spec, created_at, updated_at) VALUES (?,?,?,?,?,?)",
            (run_id, name, kind, json.dumps(spec), now, now),
        )
        self.event(run_id, "created", {"name": name, "kind": kind})
        return run_id

    def set_run_state(self, run_id: str, state: str, worker_id: str | None = None,
                      exit_code: int | None = None) -> None:
        self._exec(
            """UPDATE runs SET state=?, updated_at=?,
               worker_id=COALESCE(?, worker_id), exit_code=COALESCE(?, exit_code) WHERE id=?""",
            (state, time.time(), worker_id, exit_code, run_id),
        )
        self.event(run_id, state, {"worker": worker_id, "exit_code": exit_code})

    def next_queued(self) -> dict | None:
        rows = self._rows("SELECT * FROM runs WHERE state='queued' ORDER BY created_at LIMIT 1")
        if not rows:
            return None
        row = rows[0]
        row["spec"] = json.loads(row["spec"])
        return row

    def get_run(self, run_id: str) -> dict | None:
        rows = self._rows("SELECT * FROM runs WHERE id=?", (run_id,))
        if not rows:
            return None
        row = rows[0]
        row["spec"] = json.loads(row["spec"])
        return row

    def list_runs(self, limit: int = 50) -> list[dict]:
        return self._rows(
            "SELECT id, name, kind, state, worker_id, exit_code, created_at FROM runs "
            "ORDER BY created_at DESC LIMIT ?", (limit,))

    # -- logs & events ------------------------------------------------------
    def append_log(self, run_id: str, line: str) -> None:
        with self._lock:
            cur = self._db.execute("SELECT COALESCE(MAX(seq),0)+1 FROM logs WHERE run_id=?", (run_id,))
            seq = cur.fetchone()[0]
            self._db.execute("INSERT INTO logs (run_id, seq, ts, line) VALUES (?,?,?,?)",
                             (run_id, seq, time.time(), line))
            self._db.commit()

    def tail_logs(self, run_id: str, lines: int = 100) -> list[str]:
        rows = self._rows(
            "SELECT line FROM logs WHERE run_id=? ORDER BY seq DESC LIMIT ?", (run_id, lines))
        return [r["line"] for r in reversed(rows)]

    def event(self, run_id: str, event: str, detail: dict | None = None) -> None:
        self._exec("INSERT INTO events (run_id, ts, event, detail) VALUES (?,?,?,?)",
                   (run_id, time.time(), event, json.dumps(detail or {})))

    def run_events(self, run_id: str) -> list[dict]:
        rows = self._rows("SELECT ts, event, detail FROM events WHERE run_id=? ORDER BY ts", (run_id,))
        for r in rows:
            r["detail"] = json.loads(r["detail"])
        return rows
