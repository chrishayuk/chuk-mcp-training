"""chuk-mcp-training control plane — M0.

One process, three surfaces:
  * /ws/agent   — outbound-dial websocket for chuk-train-agent workers
  * /api/*      — REST (bearer auth) used by the MCP server and the dashboard
  * /           — dashboard stub (auto-refreshing fleet + runs view)

Run:  CHUK_TRAIN_API_TOKEN=... CHUK_TRAIN_JOIN_TOKEN=... uvicorn control_plane.app:app
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets

from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from .registry import Registry

API_TOKEN = os.environ.get("CHUK_TRAIN_API_TOKEN") or secrets.token_urlsafe(24)
JOIN_TOKEN = os.environ.get("CHUK_TRAIN_JOIN_TOKEN") or secrets.token_urlsafe(24)
DB_PATH = os.environ.get("CHUK_TRAIN_DB", "chuk_train.db")

app = FastAPI(title="chuk-mcp-training control plane", version="0.1.0")
reg = Registry(DB_PATH)
_bearer = HTTPBearer(auto_error=False)

# worker_id -> live websocket
_sockets: dict[str, WebSocket] = {}
_sched_lock = asyncio.Lock()


def _auth(creds: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> None:
    if creds is None or creds.credentials != API_TOKEN:
        raise HTTPException(status_code=401, detail="bad or missing bearer token")


# --------------------------------------------------------------------------
# Scheduler (M0: one run in flight per worker, FIFO queue, no packing yet)
# --------------------------------------------------------------------------
async def _try_assign() -> None:
    async with _sched_lock:
        for worker_id, ws in list(_sockets.items()):
            fleet = {w["id"]: w for w in reg.fleet()}
            w = fleet.get(worker_id)
            if not w or w["current_run"]:
                continue
            run = reg.next_queued()
            if run is None:
                return
            reg.set_run_state(run["id"], "assigned", worker_id=worker_id)
            reg.set_worker_run(worker_id, run["id"])
            try:
                await ws.send_text(json.dumps({
                    "type": "assign",
                    "run": {"id": run["id"], "kind": run["kind"], "spec": run["spec"]},
                }))
            except Exception:
                # socket died between checks — requeue
                reg.set_run_state(run["id"], "queued")
                reg.set_worker_run(worker_id, None)


# --------------------------------------------------------------------------
# Agent websocket
# --------------------------------------------------------------------------
@app.websocket("/ws/agent")
async def agent_ws(ws: WebSocket) -> None:
    await ws.accept()
    worker_id: str | None = None
    try:
        raw = await asyncio.wait_for(ws.receive_text(), timeout=15)
        msg = json.loads(raw)
        if msg.get("type") != "register" or msg.get("token") != JOIN_TOKEN:
            await ws.close(code=4401)
            return
        worker_id = msg.get("worker_id") or f"w-{secrets.token_hex(4)}"
        reg.upsert_worker(worker_id, msg.get("labels", []), msg.get("hardware", {}))
        _sockets[worker_id] = ws
        await ws.send_text(json.dumps({"type": "registered", "worker_id": worker_id}))
        await _try_assign()

        while True:
            msg = json.loads(await ws.receive_text())
            t = msg.get("type")
            if t == "heartbeat":
                reg.heartbeat(worker_id)
            elif t == "log":
                reg.append_log(msg["run_id"], msg["line"])
            elif t == "run_started":
                reg.set_run_state(msg["run_id"], "running", worker_id=worker_id)
            elif t == "run_exited":
                code = int(msg.get("code", -1))
                reg.set_run_state(msg["run_id"], "completed" if code == 0 else "failed",
                                  worker_id=worker_id, exit_code=code)
                reg.set_worker_run(worker_id, None)
                await _try_assign()
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    finally:
        if worker_id:
            _sockets.pop(worker_id, None)
            reg.worker_disconnected(worker_id)
            # M0: a run on a vanished worker is requeued immediately
            w = next((x for x in reg.fleet() if x["id"] == worker_id), None)
            if w and w.get("current_run"):
                reg.set_run_state(w["current_run"], "queued")
                reg.set_worker_run(worker_id, None)


# --------------------------------------------------------------------------
# REST API
# --------------------------------------------------------------------------
class ShellRun(BaseModel):
    name: str
    command: str
    timeout_s: int = 600


@app.get("/api/fleet", dependencies=[Depends(_auth)])
def api_fleet() -> list[dict]:
    return reg.fleet()


@app.post("/api/runs/shell", dependencies=[Depends(_auth)])
async def api_submit_shell(body: ShellRun) -> dict:
    run_id = reg.create_run(body.name, "shell",
                            {"command": body.command, "timeout_s": body.timeout_s})
    await _try_assign()
    return {"run_id": run_id}


@app.get("/api/runs", dependencies=[Depends(_auth)])
def api_runs(limit: int = 50) -> list[dict]:
    return reg.list_runs(limit)


@app.get("/api/runs/{run_id}", dependencies=[Depends(_auth)])
def api_run(run_id: str) -> dict:
    run = reg.get_run(run_id)
    if run is None:
        raise HTTPException(404, "no such run")
    return run


@app.get("/api/runs/{run_id}/logs", dependencies=[Depends(_auth)])
def api_logs(run_id: str, lines: int = 100) -> dict:
    return {"run_id": run_id, "lines": reg.tail_logs(run_id, lines)}


@app.get("/api/runs/{run_id}/events", dependencies=[Depends(_auth)])
def api_events(run_id: str) -> list[dict]:
    return reg.run_events(run_id)


@app.get("/healthz")
def healthz() -> dict:
    return {"ok": True}


# --------------------------------------------------------------------------
# Dashboard stub (M0: fleet + runs table, 3s refresh, token via localStorage)
# --------------------------------------------------------------------------
_DASH = """<!doctype html><html><head><meta charset="utf-8">
<title>chuk-train</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 body{font-family:ui-monospace,Menlo,monospace;background:#0d1117;color:#c9d1d9;margin:2rem}
 h1{font-size:1.1rem;color:#58a6ff} h2{font-size:.95rem;color:#8b949e;margin-top:1.6rem}
 table{border-collapse:collapse;width:100%;font-size:.85rem}
 td,th{border-bottom:1px solid #21262d;padding:.35rem .6rem;text-align:left}
 .connected{color:#3fb950}.disconnected{color:#f85149}
 .completed{color:#3fb950}.failed{color:#f85149}.running{color:#d29922}.queued{color:#8b949e}
 input{background:#161b22;color:#c9d1d9;border:1px solid #30363d;padding:.3rem;width:22rem}
</style></head><body>
<h1>chuk-mcp-training · M0</h1>
<div>token <input id="tok" placeholder="API token" onchange="localStorage.tok=this.value"></div>
<h2>fleet</h2><table id="fleet"><tr><th>worker</th><th>gpu</th><th>state</th><th>hb age</th><th>run</th></tr></table>
<h2>runs</h2><table id="runs"><tr><th>id</th><th>name</th><th>state</th><th>worker</th><th>exit</th></tr></table>
<script>
document.getElementById('tok').value = localStorage.tok || '';
async function j(p){const r=await fetch(p,{headers:{Authorization:'Bearer '+(localStorage.tok||'')}});
  if(!r.ok)throw 0; return r.json();}
async function tick(){try{
 const f=await j('/api/fleet'), r=await j('/api/runs');
 document.getElementById('fleet').innerHTML='<tr><th>worker</th><th>gpu</th><th>state</th><th>hb age</th><th>run</th></tr>'+
  f.map(w=>`<tr><td>${w.id}</td><td>${(w.hardware.gpu||'cpu')}</td><td class="${w.state}">${w.state}</td>`+
    `<td>${w.heartbeat_age_s}s</td><td>${w.current_run||''}</td></tr>`).join('');
 document.getElementById('runs').innerHTML='<tr><th>id</th><th>name</th><th>state</th><th>worker</th><th>exit</th></tr>'+
  r.map(x=>`<tr><td>${x.id}</td><td>${x.name}</td><td class="${x.state}">${x.state}</td>`+
    `<td>${x.worker_id||''}</td><td>${x.exit_code??''}</td></tr>`).join('');
}catch(e){}}
setInterval(tick,3000); tick();
</script></body></html>"""


@app.get("/", response_class=HTMLResponse)
def dashboard() -> str:
    return _DASH
