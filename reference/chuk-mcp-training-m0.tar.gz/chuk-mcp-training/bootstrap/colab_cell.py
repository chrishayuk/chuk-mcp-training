# --- chuk-train-agent Colab bootstrap (E0) — paste as one cell ---------------
# Joins this Colab session to the control plane as a worker. Everything after
# this cell is driven from MCP / the dashboard. Keep the cell running.
CONTROL_PLANE = "wss://train.chukai.io/ws/agent"   # your Fly app
JOIN_TOKEN    = "PASTE-JOIN-TOKEN"                  # from `fly secrets` (rotate freely)

!pip install -q "git+https://github.com/chrishayuk/chuk-mcp-training#subdirectory=agent"
!chuk-train-agent --url {CONTROL_PLANE} --token {JOIN_TOKEN} --labels colab
