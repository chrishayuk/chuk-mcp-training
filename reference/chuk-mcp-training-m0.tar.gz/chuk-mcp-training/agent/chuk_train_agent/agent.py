"""chuk-train-agent — M0 join loop.

Runs identically in a Colab cell, a Vast container, or any Linux box:

    python -m chuk_train_agent --url wss://train.example.com/ws/agent --token <JOIN_TOKEN>

Dials OUT to the control plane, registers hardware, heartbeats, executes assigned
shell runs, streams stdout/stderr lines back. Reconnects with backoff. M0 limits
(deliberate): no persistent log buffer while dark, one run in flight, shell kind only.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import platform
import shutil
import subprocess
import sys

import websockets

HEARTBEAT_S = 10
RECONNECT_MIN, RECONNECT_MAX = 2, 60


def detect_hardware() -> dict:
    hw: dict = {"host": platform.node(), "os": platform.platform(), "python": sys.version.split()[0]}
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                 "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10).stdout.strip()
            if out:
                name, mem, driver = [p.strip() for p in out.splitlines()[0].split(",")]
                hw.update({"gpu": name, "vram": mem, "driver": driver})
        except Exception:
            pass
    return hw


class Agent:
    def __init__(self, url: str, token: str, worker_id: str | None, labels: list[str]) -> None:
        self.url, self.token, self.worker_id, self.labels = url, token, worker_id, labels
        self.ws: websockets.WebSocketClientProtocol | None = None
        self.current: asyncio.Task | None = None

    async def send(self, msg: dict) -> None:
        if self.ws is not None:
            try:
                await self.ws.send(json.dumps(msg))
            except Exception:
                pass  # M0: drop while dark; buffered replay is an M1+ requirement

    # -- run execution ------------------------------------------------------
    async def run_shell(self, run: dict) -> None:
        run_id, spec = run["id"], run["spec"]
        await self.send({"type": "run_started", "run_id": run_id})
        code = -1
        try:
            proc = await asyncio.create_subprocess_shell(
                spec["command"],
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)

            async def pump() -> None:
                assert proc.stdout is not None
                async for raw in proc.stdout:
                    await self.send({"type": "log", "run_id": run_id,
                                     "line": raw.decode(errors="replace").rstrip("\n")})

            try:
                await asyncio.wait_for(asyncio.gather(pump(), proc.wait()),
                                       timeout=spec.get("timeout_s", 600))
                code = proc.returncode if proc.returncode is not None else -1
            except asyncio.TimeoutError:
                proc.kill()
                await self.send({"type": "log", "run_id": run_id,
                                 "line": f"[agent] killed: exceeded timeout_s={spec.get('timeout_s')}"})
                code = -9
        except Exception as e:  # noqa: BLE001
            await self.send({"type": "log", "run_id": run_id, "line": f"[agent] error: {e!r}"})
        finally:
            await self.send({"type": "run_exited", "run_id": run_id, "code": code})
            self.current = None

    # -- protocol loops -----------------------------------------------------
    async def heartbeats(self) -> None:
        while True:
            await asyncio.sleep(HEARTBEAT_S)
            await self.send({"type": "heartbeat"})

    async def session(self) -> None:
        async with websockets.connect(self.url, max_size=2**22) as ws:
            self.ws = ws
            await ws.send(json.dumps({"type": "register", "token": self.token,
                                      "worker_id": self.worker_id, "labels": self.labels,
                                      "hardware": detect_hardware()}))
            first = json.loads(await ws.recv())
            if first.get("type") != "registered":
                raise RuntimeError(f"registration rejected: {first}")
            self.worker_id = first["worker_id"]
            print(f"[chuk-train-agent] registered as {self.worker_id}", flush=True)

            hb = asyncio.create_task(self.heartbeats())
            try:
                async for raw in ws:
                    msg = json.loads(raw)
                    if msg.get("type") == "assign" and self.current is None:
                        self.current = asyncio.create_task(self.run_shell(msg["run"]))
                    elif msg.get("type") == "cancel" and self.current is not None:
                        self.current.cancel()
            finally:
                hb.cancel()
                self.ws = None

    async def forever(self) -> None:
        backoff = RECONNECT_MIN
        while True:
            try:
                await self.session()
                backoff = RECONNECT_MIN
            except Exception as e:  # noqa: BLE001
                print(f"[chuk-train-agent] disconnected ({e!r}); retry in {backoff}s", flush=True)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, RECONNECT_MAX)


def main() -> None:
    p = argparse.ArgumentParser(prog="chuk-train-agent")
    p.add_argument("--url", required=True, help="wss://host/ws/agent")
    p.add_argument("--token", required=True, help="join token")
    p.add_argument("--worker-id", default=None)
    p.add_argument("--labels", default="", help="comma-separated, e.g. colab,t4")
    a = p.parse_args()
    labels = [s for s in a.labels.split(",") if s]
    asyncio.run(Agent(a.url, a.token, a.worker_id, labels).forever())


if __name__ == "__main__":
    main()
