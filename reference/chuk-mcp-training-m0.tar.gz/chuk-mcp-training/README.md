# chuk-mcp-training

MCP-controlled remote training harness for Colab and rented single GPUs.
Spec: see `chuk-mcp-training-spec.md` (v0.4). This repo is at **M0**: join loop,
shell runs, log streaming, fleet — proven by experiment **E0**.

## Layout
- `control_plane/` — FastAPI app: `/ws/agent` (worker WSS), `/api/*` (REST, bearer auth), `/` (dashboard stub). Deploys to Fly.
- `agent/` — `chuk-train-agent`: dials out, registers hardware, heartbeats, executes assigned runs, streams logs, reconnects with backoff.
- `mcp_server.py` — chuk-mcp-server tool surface (`fleet`, `submit_shell`, `run_status`, `tail_logs`, `list_runs`, `run_events`); thin client over the REST API, runs on the Mac.
- `bootstrap/colab_cell.py` — the one Colab cell that joins a session as a worker (E0).
- `deploy/` — Dockerfile + fly.toml (`auto_stop_machines = false`; volume-backed SQLite).

## Run locally
```bash
export CHUK_TRAIN_API_TOKEN=... CHUK_TRAIN_JOIN_TOKEN=...
uvicorn control_plane.app:app --port 8700                      # control plane
python -m chuk_train_agent --url ws://127.0.0.1:8700/ws/agent \
       --token $CHUK_TRAIN_JOIN_TOKEN                          # a worker
CHUK_TRAIN_URL=http://127.0.0.1:8700 python mcp_server.py      # MCP (stdio)
```

## Deploy (Fly)
```bash
fly launch --copy-config --config deploy/fly.toml
fly volumes create chuk_train_data --size 1
fly secrets set CHUK_TRAIN_API_TOKEN=$(openssl rand -hex 24) \
                CHUK_TRAIN_JOIN_TOKEN=$(openssl rand -hex 24)
fly deploy
```
Then paste `bootstrap/colab_cell.py` (with your Fly URL + join token) into a Colab
notebook → the T4 appears in `fleet` and on the dashboard. That's E0.

## M0 limits (deliberate — see spec §14)
Shell runs only; one run in flight per worker; no lease walls, artifact store,
packing, budgets, or log buffering while the control plane is dark. M1 adds code
units, checkpoints + lineage, and resume; M2 adds leases + provable cleanup.
